package game.edu;
import java.util.Random;
public class Driver {
  
   private static BoxStack<Integer> Stack;
  
  	public static BoxStack<Integer> generateStack() {
      
      BoxStack<Integer> myBoxStack = new BoxStack<Integer>();    
      Random random = new Random();
      
      for (int i=0; i<= 4; i++) {
      	 //push one box to the box stack
      	 int x = random.nextInt(5);
     	 int y = random.nextInt(5);
     	 myBoxStack.push(x, y);
      }
      return myBoxStack;
      
    }

    // compares userStack to boxStack
  	public static boolean compareStack (BoxStack<Integer> userStack) {
  		for (int i=0; i<= 4; i++) {
            Box b1 = Stack.peek();
            Box b2 = userStack.peek();
  		
  			if (b1.getX() != b2.getX() || b1.getY() != b2.getY()) {
  				return false;
  			}
            Stack.pop();
            userStack.pop();
  		}
        return true;  
  	}
    
	public static void main(String[] args) {
      
		Stack = generateStack();
	}
}
